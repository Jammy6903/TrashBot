package com.jami.Database;

public enum LogType {
  MESSAGE_DELETED,
  MESSAGE_EDITED,
  MEMBER_JOIN_LEAVE
}
