package com.jami.Database;

public enum Command {
}
