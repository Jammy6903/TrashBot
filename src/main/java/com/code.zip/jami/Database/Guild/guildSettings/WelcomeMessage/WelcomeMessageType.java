package com.jami.Database.Guild.guildSettings.WelcomeMessage;

public enum WelcomeMessageType {
  MESSAGE,
  EMBED,
  IMAGE
}
