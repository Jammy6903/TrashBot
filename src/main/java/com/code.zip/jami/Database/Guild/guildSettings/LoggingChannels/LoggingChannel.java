package com.jami.Database.Guild.guildSettings.LoggingChannels;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

import org.bson.Document;

import com.jami.Database.LogType;

public class LoggingChannel {
  private long logChannel;
  private List<LogType> associatedLogs;

  public LoggingChannel(long id) {
    this.logChannel = id;
  }

  public LoggingChannel(Document doc) {
    this.logChannel = doc.getLong("logChannel");

    List<String> logStrings = doc.getList("associatedLogs", String.class, new ArrayList<>());
    this.associatedLogs = logStrings.stream()
        .map(LogType::valueOf) // converts "MESSAGE_DELETED" -> LogType.MESSAGE_DELETED
        .collect(Collectors.toList());
  }

  public long getLogChannel() {
    return logChannel;
  }

  public void addAssociatedLog(LogType type) {
    this.associatedLogs.add(type);
  }

  public void addAssociatedLogs(List<LogType> types) {
    this.associatedLogs.addAll(types);
  }

  public void removeAssociatedLog(LogType type) {
    this.associatedLogs.remove(type);
  }

  public List<LogType> getAssociatedLogs() {
    return associatedLogs;
  }

  public Document toDocument() {
    return new Document()
        .append("logChannel", logChannel)
        .append("associatedLogs", associatedLogs);
  }
}
