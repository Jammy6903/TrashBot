package com.jami.Database;

public enum Feature {
  LEVELLING,
  LOGGING,
  WORDS
}
