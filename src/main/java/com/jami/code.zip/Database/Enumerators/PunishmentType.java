package com.jami.Database.Enumerators;

public enum PunishmentType {
  WARN,
  TIMEOUT,
  KICK,
  BAN
}
