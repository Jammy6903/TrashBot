package com.jami.Database.Enumerators;

public enum Command {
}
