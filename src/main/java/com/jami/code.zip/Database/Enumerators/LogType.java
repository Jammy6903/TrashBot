package com.jami.Database.Enumerators;

public enum LogType {
  MESSAGE_DELETED,
  MESSAGE_EDITED,
  MEMBER_JOIN_LEAVE
}
