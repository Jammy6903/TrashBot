package com.jami.Database.Enumerators;

public enum FeatureRequestStatus {
  REQUESTED,
  APPROVED,
  DENIED,
  IMPLEMENTED
}
