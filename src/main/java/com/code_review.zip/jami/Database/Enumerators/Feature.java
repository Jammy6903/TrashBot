package com.jami.Database.Enumerators;

public enum Feature {
  LEVELLING,
  LOGGING,
  WORDS
}
