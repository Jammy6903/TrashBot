package com.jami.Database.Enumerators;

public enum WelcomeMessageType {
  TEXT,
  EMBED,
  IMAGE
}
