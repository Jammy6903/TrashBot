package com.jami.Database.Guild.Bracket;

import org.bson.Document;
import org.bson.codecs.pojo.annotations.BsonProperty;

public class Bracket {

  @BsonProperty("bracketId")
  private String bracketId;

  @BsonProperty("bracketName")
  private String bracketName;

  @BsonProperty("bracketDescription")
  private String bracketDescription;

  @BsonProperty("roleId")
  private long roleId;

  @BsonProperty("interval")
  private long interval;

  public Bracket() {

  }

}
